/*
 * JS File for histroy support and angular injection
 */
angular.module('letstagon', [ 'ngRoute', 'ngMessages','home' , 'navigation','completeProfile' ]).
	config(function($routeProvider, $httpProvider) {

	$routeProvider.when('/', {
		templateUrl : './js/pages/navigation/welcome.html',
		controller : 'NavigationController',
		controllerAs: 'controller'
	}).when('/login', {
		templateUrl : './js/pages/navigation/login.html',
		controller : 'NavigationController',
		controllerAs: 'controller'
	}).when('/resetPassword', {
		templateUrl : './js/pages/navigation/change_password.html',
		controller : 'NavigationController',
		controllerAs: 'controller'
	}).when('/cp/personalInformation', {
		templateUrl : './js/pages/completeYourProfile/personal_information.html',
		controller : 'PersonalInformationController',
		controllerAs: 'controller'
	}).when('/cp/experiences', {
		templateUrl : './js/pages/completeYourProfile/experience.html',
		controller : 'ExperienceController',
		controllerAs: 'controller'
	}).when('/cp/interests', {
		templateUrl : './js/pages/completeYourProfile/interests.html',
		controller : 'InterestsController',
		controllerAs: 'controller'
	}).when('/cp/privacy', {
		templateUrl : './js/pages/completeYourProfile/privacy_settings.html',
		controller : 'PrivacySettingsController',
		controllerAs: 'controller'
	}).otherwise('/');

	$httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
}).run(['$rootScope', '$location', function ($rootScope, $location,$scope) {
    $rootScope.$on('$routeChangeStart', function (event) {
    	var path = $location.path();
    	var isAuth = sessionStorage.authenticated;
    	$rootScope.isHome = false;
    	if (typeof(isAuth) == undefined || !isAuth && path.indexOf('cp') > -1) {
      	  event.preventDefault();
      	  // user is not still authenticated redirect him to login page with
		  // error set     	 
      	  $location.path("/");
        }else {
        	$rootScope.isHome = true;
        }
    });
}]);

