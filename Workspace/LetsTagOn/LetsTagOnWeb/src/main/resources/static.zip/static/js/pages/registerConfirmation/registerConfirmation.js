/*angular.module('letstagon', [ 'ngRoute' , 'home', 'navigation']).config(function($routeProvider, $httpProvider) {

	$routeProvider.when('/', {
		templateUrl : './js/pages/home/pre_login_home_page.html',
		controller : 'home',
		controllerAs: 'controller'
	}).when('/login', {
		templateUrl : './js//pages/login/login.html',
		controller : 'navigation',
		controllerAs: 'controller'
	}).otherwise('/');

	$httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

});
*/