/* 
 * JS File which inclused controllers for completeProfile ALL steps
 */

var completeProfile = angular.module('completeProfile', []);

/* 
 * Controller for completeProfile step1 - Personal information
 * 
 */
completeProfile.controller('PersonalInformationController', function($http,$scope,$rootScope,$location,$timeout) {
	$scope.user = {};
	$http({
	    url: '/profile/user/'+$rootScope.userId,
	    dataType: 'json',
	    method: 'GET',
	    headers: {
	        "Content-Type": "application/json"
	    }

	}).success(function(response){
		if(response.error == null){
			
			$scope.user = response.data;
			var name = $scope.user.name.split(" ");
			$scope.user.firstName = name[0];
			$scope.user.lastName = name[1];
			var dateOfBirth = new Date($scope.user.dateOfBirth);
			$scope.user.dateOfBirth = dateOfBirth.getFullYear()+ '-' + (dateOfBirth.getMonth() + 1) + '-' + dateOfBirth.getDate() ;
			$scope.user.additional = [];
			$scope.user.userAdditionalProfileAttributes.forEach(function(attribute){

				var attrName = attribute.additionalProfileAttribute.name;
				var value = attribute.value;
				var test = new Object();
				if(attrName == "TITLE"){
					$scope.user.additional.TITLE = value;
				} if(attrName == "TRANSPORT"){
					$scope.user.additional.TRANSPORT = value;
				} if(attrName == "DRIVING_LICENSE"){
					$scope.user.additional.DRIVING_LICENSE = value;
				} if(attrName == "SHIRT_SIZE"){
					$scope.user.additional.SHIRT_SIZE = value;
				} if(attrName == "CAR"){
					$scope.user.additional.CAR = value;
				}if(attrName == "VOLUNTEERED_BEFORE"){
					$scope.user.additional.VOLUNTEERED_BEFORE = value;
				}if(attrName == "INFORMATION_SESSION"){
					$scope.user.additional.INFORMATION_SESSION = value;
				}if(attrName == "DIETARY_REQUIREMENTS"){
					$scope.user.additional.DIETARY_REQUIREMENTS = value;
				}if(attrName == "MEDICAL_HISTROY"){
					$scope.user.additional.MEDICAL_HISTROY = value;
				}				
			});
		}else {
			$rootScope.actionError = response.error.errorMessage;
			$rootScope.error = true;
		}	
		
	}).error(function(error){
		$rootScope.actionError = response.error.errorMessage;
		$rootScope.error = true;
	});

	//Common on registartion and complete profile step_1
	$("#userDateOfBirth").datepicker({
        format: "yyyy-mm-dd",
        todayHighlight: true,
        endDate: new Date(),       
    }).on('changeDate', function(e){
   	    $scope.user.dateOfBirth = $(this).val();
    	$(this).focus();
        $(this).datepicker('hide');
    });
	 
	
	/*Highlight Element on focus and blur*/
	$("input").on("focus",function(){
		$(this).prev().addClass("focus-effect");
		$(this).addClass("focus-effect-input");
		$(this).next().addClass("focus-effect");
	});
	$("input").on("blur",function(){
		$(this).prev().removeClass("focus-effect");
		$(this).removeClass("focus-effect-input");
		$(this).next().removeClass("focus-effect");
	});
	$("textarea").on("focus",function(){
		$(this).prev().addClass("focus-effect");
		$(this).addClass("focus-effect-input");
		$(this).next().addClass("focus-effect");
	});
	$("textarea").on("blur",function(){
		$(this).prev().removeClass("focus-effect");
		$(this).removeClass("focus-effect-input");
		$(this).next().removeClass("focus-effect");
	});
	$scope.completeProfileForm_step1 = function(){
		$scope.user.name = $scope.user.firstName+" "+$scope.user.lastName;
		var address = new Object();
		address.id = $scope.user.addressBean.id;
		address.country = $scope.user.addressBean.country;
		address.postalCode = $scope.user.addressBean.postalCode;
		$scope.user.addressBean = address;
		$scope.user.userRole = "VLNTR";
		var userType = new Object();
		userType.id =  $scope.user.userTypeBean.id;
		$scope.user.userTypeBean = userType;
		$scope.user.id = $scope.user.id;
		$scope.user.password = $scope.user.password;
		$scope.user.userName = $scope.user.userName;
		var attributeList = [];
		for (var key in $scope.user.additional) {
			 var additionalPropertyAttribute = new Object();
			  additionalPropertyAttribute.value = $scope.user.additional[key];
			  var attribute = new Object();
			  attribute.name = key;
			  additionalPropertyAttribute.additionalProfileAttribute = attribute;
			  attributeList.push(additionalPropertyAttribute);
		}
		
		$scope.user.userAdditionalProfileAttributes = attributeList;
		$('#loading-indicator').show();
		$http({
		    url: '/profile/user/saveOrUpdate/personalInformation',
		    dataType: 'json',
		    method: 'POST',
		    data: $scope.user,
		    headers: {
		        "Content-Type": "application/json"
		    }

		}).success(function(response){
			$('#loading-indicator').hide();
			if(response.error == null){				
				$rootScope.actionSuccess = "Save successfull";
				$rootScope.success = true;
				$rootScope.error = false;
				sessionStorage.user =  JSON.stringify(response.data);
				 $timeout(function(){
					 $rootScope.success = false;
			        }, 1500);
			}else {
				$rootScope.actionError = response.error.errorMessage;
				$rootScope.error = true;
				 $timeout(function(){
					 $rootScope.error = false;
			        }, 1500);
			}	
				
		}).error(function(error){
			$('#loading-indicator').hide();
		    console.log("exception caught in catch while saving personal information"+error+" for user="+$rootScope.userId);
		});
	}
	
	
});

