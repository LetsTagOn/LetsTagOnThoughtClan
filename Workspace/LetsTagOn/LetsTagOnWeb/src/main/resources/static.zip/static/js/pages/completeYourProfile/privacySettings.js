completeProfile.controller('PrivacySettingsController', function($http,$scope,$rootScope,$location,$timeout) {
	$scope.privacy = {};
	$.fn.bootstrapSwitch.defaults.size = 'small';
	$('.BSswitch').bootstrapSwitch('state', true);
	$http({
	    url: '/privacy/user/'+$rootScope.userId,
	    dataType: 'json',
	    method: 'GET',
	    headers: {
	        "Content-Type": "application/json"
	    }

	}).success(function(response){
		$('#loading-indicator').hide();				
	}).error(function(error){
		$('#loading-indicator').hide();
	    $scope.error = error;
	});
	$scope.saveUserPrivacySettings = function(privacyField){
		$('#loading-indicator').show();
		var user = new Object();
		user.id = $rootScope.userId;
		$scope.privacy.user  = user;
		$http({
		    url: '/privacy/user/saveOrUpdate/settings',
		    dataType: 'json',
		    method: 'POST',
		    data: $scope.privacy,
		    headers: {
		        "Content-Type": "application/json"
		    }

		}).success(function(response){
			$('#loading-indicator').hide();			
					
		}).error(function(error){
			$('#loading-indicator').hide();
		    $scope.error = error;
		});
	}
});