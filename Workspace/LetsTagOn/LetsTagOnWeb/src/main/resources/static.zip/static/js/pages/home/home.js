angular.module('home', ['ngMessages' ]).controller('home', function($http,$scope) {

});
