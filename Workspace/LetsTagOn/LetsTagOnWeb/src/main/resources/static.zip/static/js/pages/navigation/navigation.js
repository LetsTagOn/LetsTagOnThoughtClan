/*
 * JS File to authenticate user + 
 * Control to change user password
 * 
 */
angular.module('navigation', ['ngMessages']).controller('NavigationController',function($rootScope, $http, $location, $route,$scope) {
				var authenticate = function(callback) {
				    $http.get('user').success(function(data) {
				      if (data.name) {
				        $rootScope.authenticated = true;
				        $('#modalLogin').modal('hide');
						$('body').removeClass('modal-open');
						$('.modal-backdrop').remove();
						$rootScope.authenticated = true;
						sessionStorage.authenticated = true;
						$rootScope.logout = true;
						//$scope.redirect("/cp/personalInformation");
						$scope.error = false;
						$rootScope.userId = data.principal.id;
				      } else {
				        $rootScope.authenticated = false;
				        sessionStorage.authenticated = false;
				        $scope.redirect("/");
				      }
				      callback && callback();
				    }).error(function() {
				      $rootScope.authenticated = false;
				      sessionStorage.authenticated = false;
				      callback && callback();
				    });
				  }
				  authenticate();
				  $scope.credentials = {};
				  $scope.login = function() {
				    $http.post('login', $.param($scope.credentials), {
				      headers : {
				        "content-type" : "application/x-www-form-urlencoded"
				      }
				    }).success(function(data) {
				      authenticate(function() {
				        if ($rootScope.authenticated) {
				          $scope.error = false;
				        } else {
				          $location.path("/");
				          $scope.error = true;
				        }
				      });
				    }).error(function(data) {
				      $location.path("/");
				      $scope.error = true;
				      $rootScope.authenticated = false;
				      sessionStorage.authenticated = false;
				    });
				  };
				  $scope.logout = function() {
					  $http.post('logout', {}).success(function() {
						    $scope.redirect("/");
						    $route.reload();
						  }).error(function(data) {
						  });
					};
					$scope.changePassword = function(){
						$('#loading-indicator').show();
						var url = window.location.href.split("?name=");
						url = url[1].split("&tid=");
						var resetPassordToken = url[1];
						var userName = url[0];
						$scope.user.userName = userName;
						$scope.user.resetPassordToken = resetPassordToken;
						$http({
						    url: '/password/resetPassword',
						    dataType: 'json',
						    method: 'POST',
						    data: $scope.user,
						    headers: {
						        "Content-Type": "application/json"
						    }

							}).success(function(response){	
								$('#loading-indicator').hide();
								if(response.error == null){
									$scope.redirect("/");
									$rootScope.successMessage = "Your password has been updated successfully";
									$('#modal-success').modal('show');
								}else {
									$rootScope.isError = true;
									$rootScope.authenticationError = response.error.errorMessage;				
									$('#modal-error').modal('show');
								}
							}).error(function(error){
								$('#loading-indicator').hide();
								$rootScope.isError = true;
								$rootScope.authenticationError = response.error.errorMessage;				
								$('#modal-error').modal('show');
							});
					}
				$scope.submitted = false;

			    $scope.interacted = function(field) {
			      return $scope.submitted || field.$dirty;
			    };
				
				$scope.forgotPassword = function(){
					$('#loading-indicator').show();
					 $scope.submitted = true;
					$http({
					    url: '/password/forgotPassword',
					    dataType: 'json',
					    method: 'POST',
					    data: $scope.user
					   

					}).success(function(response){
						$('#loading-indicator').hide();
						if(response.error == null){
							$rootScope.isSuccess = true;
							$rootScope.successMessage = "A link has been sent to specified email . Please verify and change password before link expires";
						}else {
							$rootScope.isError = true;
							$rootScope.errorMessage = response.error.errorMessage;			
						}			
					}).error(function(error){
						$('#loading-indicator').hide();
						$rootScope.isError = true;
						$rootScope.errorMessage = response.error.errorMessage;	
					});
				};
				
				$scope.redirect = function(redirectLocation){
					$location.path(redirectLocation);					
				}
				
				//User Registration
				$scope.customer = {};
				//Common on registartion and complete profile step_1
				$("#dateOfBirth").datepicker({
			        format: "yyyy-mm-dd",
			        todayHighlight: true,
			        endDate: new Date(),       
			    }).on('changeDate', function(e){
			    	$scope.customer.dateOfBirth = $(this).val();
			    	$(this).focus();
			        $(this).datepicker('hide');
			    });
				
				/*Highlight Element on focus and blur*/
				$("input").on("focus",function(){
					$(this).prev().addClass("focus-effect");
					$(this).addClass("focus-effect-input");
					$(this).next().addClass("focus-effect");
				});
				$("input").on("blur",function(){
					$(this).prev().removeClass("focus-effect");
					$(this).removeClass("focus-effect-input");
					$(this).next().removeClass("focus-effect");
				});
				//save call on registration
				$scope.registerForm = function(submitted){
					$scope.customer.name = $scope.customer.firstName+" "+$scope.customer.lastName;
					var address = new Object();
					address.country = $scope.customer.country;
					address.postalCode = $scope.customer.postalCode;
					$scope.customer.addressBean = address;
					$scope.customer.userRole = "VLNTR";
					var userType = new Object();
					userType.id = 1;
					$scope.customer.userTypeBean = userType;
					$scope.customer.dateOfBirth = $("#dateOfBirth").val();
					$('#loading-indicator').show();
					$http({
					    url: 'register/customer',
					    dataType: 'json',
					    method: 'POST',
					    data: $scope.customer,
					    headers: {
					        "Content-Type": "application/json"
					    }
					}).success(function(response){
						$('#loading-indicator').hide();
						$scope.customer = {};
						if(response.error == null){
							$('#myModal').modal('hide');
							$('body').removeClass('modal-open');
							$('.modal-backdrop').remove();
							$rootScope.registrationSuccessHeader = "Registration successfully completed";
							$rootScope.successMessageText1 = "You're almost there!";
							$rootScope.successMessageText2 = "A registration confirmation mail has been sent to your specified email.";
							$rootScope.successMessageText3 = "Kindly login with the given username and password.";
							$('#modal-success').modal('show');
							$('.registration-success-modal-dialog').css({
								top: "200px",
							});
						}else {
							$('#myModal').modal('hide');
							$('body').removeClass('modal-open');
							$('.modal-backdrop').remove();
							$rootScope.authenticationError = response.error.errorMessage;
							$('#modal-error').modal('show');	
							$('.registration-error-modal-dialog').css({
								top: "200px",
							});
						}			
					}).error(function(error){
						$rootScope.authenticationError = response.error.errorMessage;
						$('#modal-error').modal('show');
					});		
				}	
			}).directive('passwordC', function () {
			    return {
			        require: 'ngModel',
			        link: function (scope, elm, attrs, ctrl) {
			            ctrl.$parsers.unshift(function (viewValue, $scope) {
			                var noMatch = viewValue != scope.changePassForm.password.$viewValue
			                ctrl.$setValidity('noMatch', !noMatch)
			            })
			        }
			    }
			}).directive("passwordVerify", function() {
			    return {
			        require: "ngModel",
			        scope: {
			            passwordVerify: '='
			        },
			        link: function(scope, element, attrs, ctrl) {
			            scope.$watch(function() {
			                var combined;
			                
			                if (scope.passwordVerify || ctrl.$viewValue) {
			                   combined = scope.passwordVerify + '_' + ctrl.$viewValue; 
			                }                    
			                return combined;
			            }, function(value) {
			                if (value) {
			                    ctrl.$parsers.unshift(function(viewValue) {
			                        var origin = scope.passwordVerify;
			                        if (origin !== viewValue) {
			                            ctrl.$setValidity("passwordVerify", false);
			                            return undefined;
			                        } else {
			                            ctrl.$setValidity("passwordVerify", true);
			                            return viewValue;
			                        }
			                    });
			                }
			            });
			        }
			    };
			});;
